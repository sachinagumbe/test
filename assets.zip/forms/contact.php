<?php
if(isset($_POST['email'])) {

    // EDIT THE 2 LINES BELOW AS REQUIRED
    $email_to = "sachinagumbe@gmail.com";
    $email_subject = "Twin Health";
 
    function died($error) {
        // your error code can go here
        echo "We are very sorry, but there were error(s) found with the form you submitted. ";
        echo "These errors appear below.<br /><br />";
        echo $error."<br /><br />";
        echo "Please go back and fix these errors.<br /><br />";
        die();
    }
 
 
    // validation expected data exists
    if(!isset($_POST['name']) ||
        
        !isset($_POST['email']) ||
        !isset($_POST['phone']) ||
        !isset($_POST['message'])) {
        died('We are sorry, but there appears to be a problem with the form you submitted.');       
    }
 
     
 
    $name = $_POST['name']." ".$_POST['lname']; // required
    $mobileNo = $_POST['phone']; // required
    $email_from = $_POST['email']; // required
    $title = $_POST['title']; // required
    $company = $_POST['company']; // required
    $message = $_POST['message']; // required
   

    $email_message = "Form details below.\n\n";
 
     
    function clean_string($string) {
      $bad = array("content-type","bcc:","to:","cc:","href");
      return str_replace($bad,"",$string);
    }
 
     
 
    $email_message .= "Name: ".clean_string($name)."\n";
    $email_message .= "Title: ".clean_string($title)."\n";
    $email_message .= "Company: ".clean_string($company)."\n";
    $email_message .= "Email: ".clean_string($email_from)."\n";
	$email_message .= "Mobile: ".clean_string($mobileNo)."\n";
	//$email_message .= "Date of Birth: ".clean_string($dob)."\n";
	//$email_message .= "Life Style Condition: ".clean_string($lifeStyleCondition)."\n";
	//$email_message .= "Interested Program: ".clean_string($InterestedProgram)."\n";
	//$email_message .= "Call Back Preference: ".clean_string($appointment)."\n";
	//$email_message .= "Home Locality: ".clean_string($homeLocality)."\n";
	//$email_message .= "Office Locality: ".clean_string($officeLocality)."\n";
	$email_message .= "Message: ".clean_string($message)."\n";
	
    
 
// create email headers
$headers = 'From: '.$name."\r\n".
'Reply-To: '.$email_from."\r\n" .
'X-Mailer: PHP/' . phpversion();

@mail($email_to, $email_subject, $email_message, $headers);

header("Location: ../about_twin.html");
?>
 
<!-- include your own success html here -->
 

 
<?php
 
}
?>